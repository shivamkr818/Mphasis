import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcomeheader',
  templateUrl: './welcomeheader.component.html',
  styleUrls: ['./welcomeheader.component.css']
})
export class WelcomeheaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
